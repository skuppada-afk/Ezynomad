-- ═══════════════════════════════════════════════════════════
-- MIGRATION 12 — PARTNER & USER FEEDBACK
-- Stores every feedback submission. Email goes to support@ for action,
-- but the DB record is the source of truth for review and follow-up.
-- ═══════════════════════════════════════════════════════════

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  user_email text,
  user_name text,
  user_role text,
  category text not null,
  subject text,
  message text not null,
  status text default 'new', -- new | in_progress | resolved | dismissed
  admin_note text,
  created_at timestamptz default now(),
  resolved_at timestamptz
);

create index if not exists feedback_status_idx on public.feedback (status, created_at desc);
create index if not exists feedback_user_idx on public.feedback (user_id, created_at desc);

-- RLS: any authenticated user can insert their own feedback. Only admin can read.
alter table public.feedback enable row level security;

drop policy if exists "anyone can submit feedback" on public.feedback;
create policy "anyone can submit feedback"
  on public.feedback
  for insert
  to authenticated, anon
  with check (true);

drop policy if exists "only admin can read feedback" on public.feedback;
create policy "only admin can read feedback"
  on public.feedback
  for select
  to authenticated
  using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

drop policy if exists "only admin can update feedback" on public.feedback;
create policy "only admin can update feedback"
  on public.feedback
  for update
  to authenticated
  using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );
