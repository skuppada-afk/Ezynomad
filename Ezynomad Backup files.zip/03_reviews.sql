-- ═══════════════════════════════════════════════════════════
-- REVIEWS MIGRATION — run in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════

create table if not exists public.reviews (
  id uuid default gen_random_uuid() primary key,
  booking_id uuid references public.bookings(id) on delete cascade,
  property_id uuid references public.properties(id) on delete cascade,
  customer_id uuid references public.profiles(id),
  rating integer not null check (rating >= 1 and rating <= 5),
  comment text,
  is_hidden boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique(booking_id)
);

create index if not exists idx_reviews_property on public.reviews(property_id);
create index if not exists idx_reviews_customer on public.reviews(customer_id);

alter table public.reviews enable row level security;

create policy "Public can read visible reviews"
  on public.reviews for select
  using (is_hidden = false or customer_id = auth.uid() or exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));

create policy "Customers can write reviews for their bookings"
  on public.reviews for insert
  to authenticated
  with check (
    customer_id = auth.uid()
    and exists (
      select 1 from public.bookings
      where id = booking_id and customer_id = auth.uid() and status = 'confirmed'
    )
  );

create policy "Customers can update own reviews"
  on public.reviews for update
  to authenticated
  using (customer_id = auth.uid())
  with check (customer_id = auth.uid());

create policy "Admins can update any review"
  on public.reviews for update
  to authenticated
  using (exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

create policy "Customers can delete own reviews"
  on public.reviews for delete
  to authenticated
  using (customer_id = auth.uid() or exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  ));
