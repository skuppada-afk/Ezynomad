-- ═══════════════════════════════════════════════════════════
-- MIGRATION 05 — LOCATION COORDINATES
-- Adds latitude/longitude columns to properties for map display.
-- Safe to run multiple times (uses IF NOT EXISTS).
-- ═══════════════════════════════════════════════════════════

alter table public.properties
  add column if not exists latitude numeric(10, 7),
  add column if not exists longitude numeric(10, 7);

-- Index for future geographic queries (e.g. "properties within X km of point")
create index if not exists idx_properties_location
  on public.properties (latitude, longitude)
  where latitude is not null and longitude is not null;

-- No RLS changes needed. Existing SELECT policies already cover these columns.
