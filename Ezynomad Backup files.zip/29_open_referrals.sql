-- ═══════════════════════════════════════════════════════════
-- MIGRATION 29 — OPEN REFERRALS (no account needed to refer)
-- A referrer can submit a referral without registering. The
-- referral stores their contact details and email. referrer_id
-- stays null until they create an account; on signup, pending
-- referrals matching their email get linked to their account.
-- ═══════════════════════════════════════════════════════════

-- referrer_id may now be null (guest referral, not yet linked)
alter table public.referrals
  alter column referrer_id drop not null;

-- Store the referrer's own contact details
alter table public.referrals
  add column if not exists referrer_email text,
  add column if not exists referrer_name text,
  add column if not exists referrer_phone text;

-- Allow anyone to create a referral (open form, no login required)
drop policy if exists "Users can create referrals" on public.referrals;
drop policy if exists "Anyone can create referrals" on public.referrals;
create policy "Anyone can create referrals"
  on public.referrals
  for insert
  with check (true);

-- Helper index for linking pending referrals to an account by email
create index if not exists referrals_referrer_email_idx
  on public.referrals (lower(referrer_email));

-- Force PostgREST to reload the table schema right away, so the new
-- columns are usable from the frontend without restarting anything.
notify pgrst, 'reload schema';
