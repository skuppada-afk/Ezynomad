-- ═══════════════════════════════════════════════════════════
-- PROFILE + DEACTIVATION MIGRATION — run in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════

-- 1. Add phone to profiles, plus deactivation column
alter table public.profiles
  add column if not exists phone text,
  add column if not exists is_active boolean default true,
  add column if not exists deactivated_at timestamptz;

-- 2. Properties already have a "status" column with 'suspended' option.
--    Add a 'deactivated' option so admin-deletes are distinguishable from owner-suspensions.
alter table public.properties
  drop constraint if exists properties_status_check;
alter table public.properties
  add constraint properties_status_check
  check (status in ('active', 'suspended', 'draft', 'deactivated'));

-- 3. Update RLS policy so deactivated properties are hidden from public browsing
drop policy if exists "Active properties are viewable by everyone" on public.properties;
create policy "Active properties are viewable by everyone"
  on public.properties for select using (
    status = 'active'
    or owner_id = auth.uid()
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- 4. Allow profiles to be updated by their owner (already exists but make sure)
drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile"
  on public.profiles for update using (
    auth.uid() = id
    or exists (select 1 from public.profiles p2 where p2.id = auth.uid() and p2.role = 'admin')
  );
