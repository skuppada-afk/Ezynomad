// netlify/functions/razorpay-verify-payment.js
//
// Verifies a Razorpay payment signature after the guest completes payment.
// Razorpay signs (order_id + "|" + payment_id) with the key secret using
// HMAC-SHA256. We recompute it and compare. Only a match means the payment
// is genuine.
//
// Required Netlify environment variable:
//   RAZORPAY_KEY_SECRET - secret, server-only

const crypto = require('crypto');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keySecret) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Razorpay secret is not configured on the server.' })
    };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid request body.' }) };
  }

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = body;

  // All three fields are required
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return {
      statusCode: 400,
      body: JSON.stringify({ verified: false, error: 'Missing payment verification fields.' })
    };
  }

  // Recompute the signature
  const expected = crypto
    .createHmac('sha256', keySecret)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  // Constant-time comparison to avoid timing attacks
  let match = false;
  try {
    const a = Buffer.from(expected, 'utf8');
    const b = Buffer.from(razorpay_signature, 'utf8');
    match = a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch (e) {
    match = false;
  }

  if (!match) {
    // Signature mismatch - do NOT treat the payment as successful
    return {
      statusCode: 400,
      body: JSON.stringify({ verified: false, error: 'Payment signature verification failed.' })
    };
  }

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      verified: true,
      payment_id: razorpay_payment_id,
      order_id: razorpay_order_id
    })
  };
};
