-- ═══════════════════════════════════════════════════════════
-- MIGRATION 27 — ALLOW GUEST BOOKINGS
-- The original insert policy required auth.uid() to be non-null,
-- so only logged-in users could create a booking. The platform
-- supports guest bookings (no account), where auth.uid() is null.
-- This replaces the policy to allow anyone to create a booking.
-- The booking row carries its own customer_name / customer_email,
-- so an account is not required.
-- ═══════════════════════════════════════════════════════════

drop policy if exists "Authenticated users can create bookings" on public.bookings;

create policy "Anyone can create bookings"
  on public.bookings
  for insert
  with check (true);
