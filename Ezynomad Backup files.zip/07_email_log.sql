-- ═══════════════════════════════════════════════════════════
-- MIGRATION 07 — EMAIL LOG
-- Tracks emails sent so we never double-send a confirmation.
-- ═══════════════════════════════════════════════════════════

create table if not exists public.email_log (
  id uuid default gen_random_uuid() primary key,
  booking_id uuid references public.bookings(id) on delete cascade,
  recipient text not null,
  email_type text not null check (email_type in (
    'booking_confirmation_customer',
    'booking_notification_partner',
    'booking_cancelled_customer',
    'booking_cancelled_partner',
    'review_request',
    'pre_arrival_reminder'
  )),
  status text default 'sent' check (status in ('sent', 'failed')),
  provider_message_id text,
  error_message text,
  sent_at timestamptz default now()
);

-- One email per booking per type. Idempotency lock.
create unique index if not exists idx_email_log_booking_type
  on public.email_log (booking_id, email_type)
  where booking_id is not null;

create index if not exists idx_email_log_recipient on public.email_log (recipient);
create index if not exists idx_email_log_sent_at on public.email_log (sent_at desc);

-- RLS: only service role writes. Customers/partners can read their own.
alter table public.email_log enable row level security;

drop policy if exists "Service role manages email log" on public.email_log;
create policy "Service role manages email log"
  on public.email_log for all
  using (auth.role() = 'service_role')
  with check (auth.role() = 'service_role');

drop policy if exists "Users can view their own emails" on public.email_log;
create policy "Users can view their own emails"
  on public.email_log for select
  using (
    exists (
      select 1 from public.bookings b
      where b.id = email_log.booking_id
        and (b.customer_id = auth.uid()
             or exists (
               select 1 from public.properties p
               where p.id = b.property_id and p.owner_id = auth.uid()
             ))
    )
  );
