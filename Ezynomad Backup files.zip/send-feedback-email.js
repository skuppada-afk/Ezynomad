// Netlify function: forwards a feedback submission to support@ezynomad.com.
// The DB record is the source of truth; this function is a fire-and-forget notifier.

const { Resend } = require('resend');

const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME = 'Ezynomad';
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || 'support@ezynomad.com';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const CATEGORY_LABELS = {
  bug: '🐛 Bug',
  feature: '💡 Feature request',
  listing: '📝 Listing help',
  bookings: '📅 Bookings / payments',
  general: '💬 General feedback',
  other: 'Other'
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { category, subject, message, user_email, user_name, user_role } = JSON.parse(event.body || '{}');

    if (!message || message.length < 10) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Message required' }) };
    }

    const catLabel = CATEGORY_LABELS[category] || 'Other';
    const subjectLine = subject
      ? `[Feedback - ${catLabel}] ${subject}`
      : `[Feedback - ${catLabel}] from ${user_name || user_email || 'a user'}`;

    const html = feedbackEmailHTML({ catLabel, subject, message, user_email, user_name, user_role });
    const text = feedbackEmailText({ catLabel, subject, message, user_email, user_name, user_role });

    const { data, error } = await resend.emails.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: SUPPORT_EMAIL,
      reply_to: user_email || undefined, // so admin can hit Reply and respond to the user directly
      subject: subjectLine,
      html,
      text,
    });
    if (error) throw new Error(error.message || JSON.stringify(error));

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, message_id: data?.id }),
    };
  } catch (err) {
    console.error('send-feedback-email error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function feedbackEmailHTML({ catLabel, subject, message, user_email, user_name, user_role }) {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Feedback received</title></head>
<body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px">
<tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">

<tr><td style="padding:20px 28px;background:#0C1A2E;color:#FFFFFF">
<div style="font-size:13px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">Feedback received</div>
<div style="font-size:18px;font-weight:700">${escapeHtml(catLabel)}</div>
</td></tr>

<tr><td style="padding:24px 28px">
${subject ? `<div style="font-family:Georgia,serif;font-size:20px;color:#0F172A;margin-bottom:16px">${escapeHtml(subject)}</div>` : ''}

<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:20px;background:#F8FAFC;border-radius:10px">
<tr><td style="padding:14px 16px">
<div style="font-size:11px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">From</div>
<div style="font-size:14px;color:#0F172A"><b>${escapeHtml(user_name || 'Anonymous')}</b>${user_role ? ` <span style="color:#94A3B8;font-size:12px">(${escapeHtml(user_role)})</span>` : ''}</div>
${user_email ? `<div style="font-size:13px;color:#475569;margin-top:2px"><a href="mailto:${escapeHtml(user_email)}" style="color:#0E7490;text-decoration:none">${escapeHtml(user_email)}</a></div>` : ''}
</td></tr>
</table>

<div style="font-size:11px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Message</div>
<div style="font-size:15px;color:#0F172A;white-space:pre-wrap;background:#FFFBEB;border-left:3px solid #F97316;padding:14px 16px;border-radius:6px;line-height:1.6">${escapeHtml(message)}</div>

${user_email ? `
<div style="margin-top:24px;font-size:13px;color:#64748B">
  Hit Reply to respond to ${escapeHtml(user_name || user_email)} directly.
</div>` : ''}
</td></tr>

<tr><td style="padding:14px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">
Ezynomad.com — feedback notification
</td></tr>

</table>
</td></tr>
</table>
</body></html>`;
}

function feedbackEmailText({ catLabel, subject, message, user_email, user_name, user_role }) {
  return `Feedback received — ${catLabel}

${subject ? `Subject: ${subject}\n` : ''}
From: ${user_name || 'Anonymous'}${user_role ? ` (${user_role})` : ''}
${user_email ? `Email: ${user_email}\n` : ''}

Message:
${message}

${user_email ? `\nReply directly to: ${user_email}\n` : ''}
`;
}
