-- ═══════════════════════════════════════════════════════════
-- MIGRATION 17 — CANCELLATION & REFUND POLICY ON PROPERTIES
-- Adds a cancellation policy field that partners set when listing.
-- cancellation_policy: one of flexible / moderate / strict / non-refundable / custom
-- cancellation_policy_custom: free text, used only when policy = 'custom'
-- ═══════════════════════════════════════════════════════════

alter table public.properties
  add column if not exists cancellation_policy text default 'flexible',
  add column if not exists cancellation_policy_custom text;
