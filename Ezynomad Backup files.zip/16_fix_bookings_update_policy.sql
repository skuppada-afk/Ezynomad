-- ═══════════════════════════════════════════════════════════
-- MIGRATION 16 — FIX BOOKINGS UPDATE POLICY
-- The original policy only let admins update bookings, so partner
-- cancellations and customer cancellations silently failed.
-- This replaces it so:
--   - admins can update any booking
--   - a property owner (partner) can update bookings on their property
--   - a customer can update their own booking (matched by customer_id)
-- ═══════════════════════════════════════════════════════════

drop policy if exists "Admins can update bookings" on public.bookings;

create policy "Admins partners and customers can update bookings"
  on public.bookings
  for update
  using (
    -- admin
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
    -- property owner (partner) for a booking on their property
    or exists (select 1 from public.properties where id = property_id and owner_id = auth.uid())
    -- the customer who made the booking
    or customer_id = auth.uid()
  )
  with check (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
    or exists (select 1 from public.properties where id = property_id and owner_id = auth.uid())
    or customer_id = auth.uid()
  );
