// Netlify function: invites a user via Supabase admin SDK.
// Only callable by authenticated admin users.
// Creates the auth user, sends them a magic-link invite email, and pre-creates a profile row.

const { createClient } = require('@supabase/supabase-js');

// Admin client uses the service role key (NEVER expose this in browser code)
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
  { auth: { autoRefreshToken: false, persistSession: false } }
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    // ────────── Verify the caller is an admin ──────────
    const authHeader = event.headers.authorization || event.headers.Authorization || '';
    const token = authHeader.replace(/^Bearer\s+/i, '');
    if (!token) {
      return { statusCode: 401, headers: corsHeaders, body: JSON.stringify({ error: 'Missing auth token' }) };
    }

    // Verify the token + look up the caller's profile
    const { data: { user: caller }, error: callerErr } = await supabaseAdmin.auth.getUser(token);
    if (callerErr || !caller) {
      return { statusCode: 401, headers: corsHeaders, body: JSON.stringify({ error: 'Invalid token' }) };
    }
    const { data: callerProfile } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', caller.id)
      .maybeSingle();
    if (!callerProfile) {
      return { statusCode: 403, headers: corsHeaders, body: JSON.stringify({ error: 'Profile not found' }) };
    }
    const isAdmin = callerProfile.role === 'admin';

    // ────────── Parse + validate ──────────
    const { email, name, role, phone, whatsapp, note } = JSON.parse(event.body || '{}');
    if (!email || !email.includes('@')) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Valid email required' }) };
    }
    if (!name) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Name required' }) };
    }
    if (!['partner', 'customer', 'admin'].includes(role)) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Invalid role' }) };
    }
    // Non-admins can only invite partners (referrals program). Admins can invite any role.
    if (!isAdmin && role !== 'partner') {
      return { statusCode: 403, headers: corsHeaders, body: JSON.stringify({ error: 'Only admins can invite this role' }) };
    }

    // ────────── Check if user already exists ──────────
    const { data: existing } = await supabaseAdmin
      .from('profiles')
      .select('id, email')
      .eq('email', email)
      .maybeSingle();
    if (existing) {
      return {
        statusCode: 409,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'A user with this email already exists' })
      };
    }

    // ────────── Send the invite ──────────
    // Supabase's inviteUserByEmail creates the auth user and emails them a magic link
    // that lets them set their password.
    // The redirectTo decides where they land after clicking the link.
    const siteUrl = process.env.SITE_URL || 'https://ezynomad.com';
    const { data: inviteData, error: inviteErr } = await supabaseAdmin.auth.admin.inviteUserByEmail(email, {
      data: {
        full_name: name,
        role,
        invited_by: caller.email,
        invite_note: note || null
      },
      redirectTo: `${siteUrl}/reset-password`
    });

    if (inviteErr) {
      console.error('Invite failed', inviteErr);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ error: inviteErr.message || 'Invite failed' })
      };
    }

    // ────────── Pre-create the profile row ──────────
    // This way the partner has a profile from day one and bookings won't fail FK checks.
    const newUserId = inviteData?.user?.id;
    if (newUserId) {
      const { error: profileErr } = await supabaseAdmin.from('profiles').insert({
        id: newUserId,
        email,
        full_name: name,
        role,
        phone: phone || null,
        whatsapp: whatsapp || null
      });
      if (profileErr) {
        console.warn('Profile row insert failed (user still invited):', profileErr);
      }
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ok: true,
        user_id: newUserId,
        message: `Invite sent to ${email}`
      })
    };
  } catch (err) {
    console.error('invite-user error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) })
    };
  }
};
