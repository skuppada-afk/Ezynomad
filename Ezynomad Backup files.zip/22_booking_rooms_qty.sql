-- ═══════════════════════════════════════════════════════════
-- MIGRATION 22 — ROOMS QUANTITY ON BOOKINGS
-- A guest can book more than one room of the same type
-- (larger families or groups). rooms_qty stores how many.
-- Existing bookings default to 1.
-- ═══════════════════════════════════════════════════════════

alter table public.bookings
  add column if not exists rooms_qty integer default 1;
