-- ═══════════════════════════════════════════════════════════
-- MIGRATION 23 — MULTI-ROOM-TYPE BOOKINGS
-- A booking can now include several room types at once
-- (e.g. 2 Standard + 1 Suite). room_items stores the full
-- breakdown as JSON. room_id / rooms_qty are kept for
-- backward compatibility: room_id = the first room type,
-- rooms_qty = the total room count across all types.
-- ═══════════════════════════════════════════════════════════

alter table public.bookings
  add column if not exists room_items jsonb;
