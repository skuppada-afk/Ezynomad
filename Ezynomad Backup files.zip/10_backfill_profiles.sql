-- ═══════════════════════════════════════════════════════════
-- BACKFILL — ENSURE EVERY AUTH USER HAS A PROFILE ROW
-- Older signups (before profile auto-creation) may not have a profiles row.
-- That breaks bookings because bookings.customer_id references profiles.id.
-- This backfill creates the missing rows from auth.users metadata.
-- Safe to run multiple times.
-- ═══════════════════════════════════════════════════════════

insert into public.profiles (id, email, full_name, role)
select
  u.id,
  u.email,
  coalesce(u.raw_user_meta_data->>'full_name', split_part(u.email, '@', 1)) as full_name,
  coalesce(u.raw_user_meta_data->>'role', 'customer') as role
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null;
