-- ═══════════════════════════════════════════════════════════
-- MIGRATION 20 — ADULTS & CHILDREN ON BOOKINGS
-- The search and booking forms now capture adults and kids
-- (under 12) separately. 'guests' stays as the total for
-- backward compatibility; these columns store the breakdown.
-- ═══════════════════════════════════════════════════════════

alter table public.bookings
  add column if not exists adults integer default 1,
  add column if not exists children integer default 0;
