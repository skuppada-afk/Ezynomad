// Netlify function: sends cancellation notification emails when a booking is cancelled.
// Emails BOTH the customer and the property partner.
// Triggered by the frontend after status is set to 'cancelled' in the DB.

const { createClient } = require('@supabase/supabase-js');
const { Resend } = require('resend');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);
const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME = 'Ezynomad';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { booking_id, cancelled_by, reason } = JSON.parse(event.body || '{}');
    if (!booking_id) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'booking_id required' }) };
    }

    const { data: booking, error: bErr } = await supabase
      .from('bookings')
      .select('*')
      .eq('id', booking_id)
      .single();
    if (bErr || !booking) {
      return { statusCode: 404, headers: corsHeaders, body: JSON.stringify({ error: 'Booking not found' }) };
    }
    if (booking.status !== 'cancelled') {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Booking is not cancelled' }) };
    }

    const { data: property } = await supabase
      .from('properties')
      .select('name, city, country, owner_id')
      .eq('id', booking.property_id)
      .maybeSingle();

    let partnerEmail = null;
    if (property?.owner_id) {
      const { data: owner } = await supabase
        .from('profiles')
        .select('email')
        .eq('id', property.owner_id)
        .maybeSingle();
      partnerEmail = owner?.email || null;
    }

    const reasonText = reason || booking.cancellation_reason || 'Not specified';
    const whoCancelled = cancelled_by === 'partner' ? 'the property'
                       : cancelled_by === 'admin' ? 'Ezynomad'
                       : 'the guest';

    const results = { customer: null, partner: null };

    if (booking.customer_email) {
      try {
        const r = await resend.emails.send({
          from: `${FROM_NAME} <${FROM_EMAIL}>`,
          to: booking.customer_email,
          subject: `Your booking at ${property?.name || 'Ezynomad'} was cancelled`,
          html: customerHTML(booking, property, reasonText, whoCancelled),
          text: customerText(booking, property, reasonText, whoCancelled),
        });
        results.customer = r.error ? `error: ${r.error.message}` : 'sent';
      } catch (e) {
        results.customer = `error: ${e.message}`;
      }
    }

    if (partnerEmail) {
      try {
        const r = await resend.emails.send({
          from: `${FROM_NAME} <${FROM_EMAIL}>`,
          to: partnerEmail,
          subject: `Booking cancelled — ${property?.name || 'your property'} (${booking.checkin})`,
          html: partnerHTML(booking, property, reasonText, whoCancelled),
          text: partnerText(booking, property, reasonText, whoCancelled),
        });
        results.partner = r.error ? `error: ${r.error.message}` : 'sent';
      } catch (e) {
        results.partner = `error: ${e.message}`;
      }
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, results }),
    };
  } catch (err) {
    console.error('send-cancellation-email error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};

function shell(inner) {
  return `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">
${inner}
<tr><td style="padding:16px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">Ezynomad.com — long-stay homes for travellers</td></tr>
</table></td></tr></table></body></html>`;
}

function customerHTML(b, p, reason, who) {
  return shell(`
<tr><td style="padding:22px 28px;background:#0C1A2E;color:#FFFFFF">
<div style="font-size:13px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">Booking cancelled</div>
<div style="font-size:20px;font-weight:700">${escapeHtml(p?.name || 'Your booking')}</div>
</td></tr>
<tr><td style="padding:26px 28px">
<div style="font-size:15px;color:#475569;margin-bottom:18px">Your booking has been cancelled by ${escapeHtml(who)}. Here are the details for your records.</div>
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border-radius:10px;margin-bottom:18px"><tr><td style="padding:14px 16px;font-size:14px">
<div style="padding:3px 0"><span style="color:#64748B">Property:</span> <b>${escapeHtml(p?.name || '')}</b></div>
<div style="padding:3px 0"><span style="color:#64748B">Location:</span> ${escapeHtml(p?.city || '')}, ${escapeHtml(p?.country || '')}</div>
<div style="padding:3px 0"><span style="color:#64748B">Dates:</span> ${escapeHtml(b.checkin)} to ${escapeHtml(b.checkout)}</div>
<div style="padding:3px 0"><span style="color:#64748B">Guests:</span> ${escapeHtml(String(b.guests || 1))}</div>
<div style="padding:3px 0"><span style="color:#64748B">Reason:</span> ${escapeHtml(reason)}</div>
</td></tr></table>
<div style="font-size:14px;color:#475569;margin-bottom:8px">If you paid anything, any applicable refund will be processed per our cancellation policy. Questions? Reply to this email or write to support@ezynomad.com.</div>
<div style="margin-top:18px"><a href="https://ezynomad.com" style="display:inline-block;padding:12px 26px;background:#0E7490;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;font-size:14px">Find another stay</a></div>
</td></tr>`);
}

function customerText(b, p, reason, who) {
  return `Booking cancelled

Your booking has been cancelled by ${who}.

Property: ${p?.name || ''}
Location: ${p?.city || ''}, ${p?.country || ''}
Dates: ${b.checkin} to ${b.checkout}
Guests: ${b.guests || 1}
Reason: ${reason}

Any applicable refund will be processed per our cancellation policy.
Questions: support@ezynomad.com`;
}

function partnerHTML(b, p, reason, who) {
  return shell(`
<tr><td style="padding:22px 28px;background:#0C1A2E;color:#FFFFFF">
<div style="font-size:13px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">Booking cancelled</div>
<div style="font-size:20px;font-weight:700">${escapeHtml(p?.name || 'Your property')}</div>
</td></tr>
<tr><td style="padding:26px 28px">
<div style="font-size:15px;color:#475569;margin-bottom:18px">A booking on your property has been cancelled by ${escapeHtml(who)}. The dates are now open again on your calendar.</div>
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border-radius:10px;margin-bottom:18px"><tr><td style="padding:14px 16px;font-size:14px">
<div style="padding:3px 0"><span style="color:#64748B">Guest:</span> <b>${escapeHtml(b.customer_name || '')}</b></div>
<div style="padding:3px 0"><span style="color:#64748B">Dates:</span> ${escapeHtml(b.checkin)} to ${escapeHtml(b.checkout)}</div>
<div style="padding:3px 0"><span style="color:#64748B">Guests:</span> ${escapeHtml(String(b.guests || 1))}</div>
<div style="padding:3px 0"><span style="color:#64748B">Reason:</span> ${escapeHtml(reason)}</div>
</td></tr></table>
<div style="font-size:13px;color:#64748B">No action needed. This is just to keep you informed.</div>
</td></tr>`);
}

function partnerText(b, p, reason, who) {
  return `Booking cancelled

A booking on ${p?.name || 'your property'} was cancelled by ${who}.

Guest: ${b.customer_name || ''}
Dates: ${b.checkin} to ${b.checkout}
Guests: ${b.guests || 1}
Reason: ${reason}

The dates are open again on your calendar. No action needed.`;
}
