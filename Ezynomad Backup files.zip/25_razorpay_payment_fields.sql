-- ═══════════════════════════════════════════════════════════
-- MIGRATION 25 — ONLINE PAYMENT FIELDS ON BOOKINGS
-- Guests can now pay online via Razorpay, or pay at the property.
-- These columns record which method was used and the payment IDs.
-- ═══════════════════════════════════════════════════════════

alter table public.bookings
  add column if not exists payment_method text default 'pay_at_property',
  add column if not exists payment_status text default 'pending',
  add column if not exists razorpay_payment_id text,
  add column if not exists razorpay_order_id text;

-- payment_method: 'pay_at_property' | 'online'
-- payment_status: 'pending' (pay at property) | 'paid' (online, verified)
