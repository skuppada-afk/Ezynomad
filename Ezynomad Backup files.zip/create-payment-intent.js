// netlify/functions/create-payment-intent.js
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };
  try {
    const { amount, currency, booking, customer_id } = JSON.parse(event.body);
    const { data: bookingRow, error } = await supabase.from('bookings').insert({
      customer_id: customer_id || null,
      property_id: booking.property_id,
      room_id: booking.room_id === 'default' ? null : booking.room_id,
      checkin: booking.checkin,
      checkout: booking.checkout,
      guests: booking.guests,
      subtotal_usd: booking.subtotal,
      fee_usd: booking.fee,
      total_usd: booking.total,
      status: 'pending'
    }).select().single();
    if (error) throw error;
    const intent = await stripe.paymentIntents.create({
      amount,
      currency: currency || 'usd',
      metadata: { booking_id: bookingRow.id, property_id: booking.property_id },
      automatic_payment_methods: { enabled: true }
    });
    await supabase.from('bookings').update({ stripe_payment_intent_id: intent.id }).eq('id', bookingRow.id);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clientSecret: intent.client_secret, bookingId: bookingRow.id })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
