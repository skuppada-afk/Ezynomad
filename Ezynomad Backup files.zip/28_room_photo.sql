-- ═══════════════════════════════════════════════════════════
-- MIGRATION 28 — ROOM PHOTO
-- Each room type can have its own cover photo, set by the partner
-- in the listing form. Stored as a public URL (uploaded to the
-- existing property-photos storage bucket).
-- ═══════════════════════════════════════════════════════════

alter table public.rooms
  add column if not exists photo_url text;
