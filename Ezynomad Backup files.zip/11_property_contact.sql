-- ═══════════════════════════════════════════════════════════
-- MIGRATION 11 — PROPERTY PUBLIC CONTACT INFO
-- Lets partners surface a public website, contact email, and contact phone
-- on their property page so guests can reach the property directly.
-- All three are optional.
-- ═══════════════════════════════════════════════════════════

alter table public.properties
  add column if not exists website text,
  add column if not exists contact_email text,
  add column if not exists contact_phone text;
