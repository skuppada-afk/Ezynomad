// netlify/functions/razorpay-create-order.js
//
// Creates a Razorpay order. The frontend sends the amount already converted
// to INR paise (it uses the same exchange rates it shows the guest, so the
// charged amount matches the displayed amount). This function validates the
// amount and asks Razorpay to create an order.
//
// Required Netlify environment variables:
//   RAZORPAY_KEY_ID      - public-ish key id (also used by the frontend)
//   RAZORPAY_KEY_SECRET  - secret, server-only, never sent to the browser

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Razorpay keys are not configured on the server.' })
    };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid request body.' }) };
  }

  const { amount, currency, receipt } = body;

  // Amount must be an integer number of paise, at least 100 (Razorpay minimum)
  const paise = Math.round(Number(amount));
  if (!Number.isFinite(paise) || paise < 100) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Amount must be at least 100 paise.' })
    };
  }

  try {
    const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
    const resp = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        amount: paise,
        currency: currency || 'INR',
        receipt: receipt || `rcpt_${Date.now()}`,
        payment_capture: 1
      })
    });

    const data = await resp.json();

    // ── Diagnostic logging (temporary). Visible only in Netlify function logs.
    console.log('[razorpay] key_id present:', !!keyId, 'len:', keyId ? keyId.length : 0);
    console.log('[razorpay] key_secret present:', !!keySecret, 'len:', keySecret ? keySecret.length : 0);
    console.log('[razorpay] response status:', resp.status);
    console.log('[razorpay] response body:', JSON.stringify(data));

    if (resp.status === 401) {
      const detail = (data && data.error && data.error.description) || 'no detail';
      console.log('[razorpay] 401 detail:', detail);
      return { statusCode: 401, body: JSON.stringify({ error: 'Razorpay authentication failed: ' + detail }) };
    }
    if (!resp.ok) {
      const msg = (data && data.error && data.error.description) || 'Razorpay order creation failed.';
      return { statusCode: 500, body: JSON.stringify({ error: msg }) };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        order_id: data.id,
        amount: data.amount,
        currency: data.currency,
        key_id: keyId   // safe to expose; the frontend needs it to open the modal
      })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message || 'Unexpected error.' }) };
  }
};
