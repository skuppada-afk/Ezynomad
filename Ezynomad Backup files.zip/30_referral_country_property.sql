-- ═══════════════════════════════════════════════════════════
-- MIGRATION 30 — REFERRAL COUNTRY & PROPERTY NAME
-- The refer form now also captures the referrer's country, the
-- referred property's country, and the property's name (separate
-- from the contact person's name).
-- ═══════════════════════════════════════════════════════════

alter table public.referrals
  add column if not exists referrer_country text,
  add column if not exists referee_country text,
  add column if not exists referee_property_name text;

-- Force PostgREST to reload the table schema.
notify pgrst, 'reload schema';
