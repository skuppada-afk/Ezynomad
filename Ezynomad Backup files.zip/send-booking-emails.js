// ═══════════════════════════════════════════════════════════
// SEND-BOOKING-EMAILS
// Called by frontend right after a booking is inserted.
// Sends:
//   - Confirmation to customer
//   - Notification to partner
// Idempotent: writes to email_log table, won't double-send.
//
// Required environment variables (set in Netlify dashboard):
//   RESEND_API_KEY        — from resend.com dashboard
//   SUPABASE_URL          — same as frontend
//   SUPABASE_SERVICE_KEY  — service role key (NOT anon key!)
//   FROM_EMAIL            — support@ezynomad.com (must be verified in Resend)
//   SUPPORT_EMAIL         — support@ezynomad.com (or your personal email for now)
// ═══════════════════════════════════════════════════════════

const { createClient } = require('@supabase/supabase-js');
const { Resend } = require('resend');

const resend = new Resend(process.env.RESEND_API_KEY);

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
  { auth: { persistSession: false } }
);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME = 'Ezynomad';
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || 'support@ezynomad.com';
const SITE_URL = process.env.SITE_URL || 'https://ezynomad.com';

exports.handler = async (event) => {
  // CORS for browser calls
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: 'Method not allowed' };
  }

  try {
    const { booking_id } = JSON.parse(event.body || '{}');
    if (!booking_id) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'booking_id required' }) };
    }

    // Pull booking first (no joins, so it works regardless of FK constraint names)
    const { data: booking, error: bErr } = await supabase
      .from('bookings')
      .select('*')
      .eq('id', booking_id)
      .single();

    if (bErr || !booking) {
      console.error('Booking lookup failed', bErr);
      return { statusCode: 404, headers: corsHeaders, body: JSON.stringify({ error: 'Booking not found' }) };
    }

    // Pull related property data
    const { data: property } = await supabase
      .from('properties')
      .select('id, name, city, country, address_line, checkin_time, checkout_time, house_rules, owner_id, photos')
      .eq('id', booking.property_id)
      .maybeSingle();
    booking.properties = property || null;

    // Pull partner profile (owner) separately
    if (property?.owner_id) {
      const { data: owner } = await supabase
        .from('profiles')
        .select('full_name, email')
        .eq('id', property.owner_id)
        .maybeSingle();
      if (booking.properties) booking.properties.owner = owner || null;
    }

    // Pull room data if there's a room_id
    if (booking.room_id) {
      const { data: room } = await supabase
        .from('rooms')
        .select('name, beds')
        .eq('id', booking.room_id)
        .maybeSingle();
      booking.rooms = room || null;
    } else {
      booking.rooms = null;
    }

    // Pull WhatsApp numbers for both sides if available, used for click-to-chat buttons in emails
    let hostWhatsApp = null;
    if (booking.properties?.owner_id) {
      const { data: ownerProfile } = await supabase
        .from('profiles')
        .select('whatsapp')
        .eq('id', booking.properties.owner_id)
        .maybeSingle();
      hostWhatsApp = (ownerProfile?.whatsapp || '').replace(/[^0-9]/g, '') || null;
    }
    let guestWhatsApp = null;
    if (booking.customer_id) {
      const { data: custProfile } = await supabase
        .from('profiles')
        .select('whatsapp')
        .eq('id', booking.customer_id)
        .maybeSingle();
      guestWhatsApp = (custProfile?.whatsapp || '').replace(/[^0-9]/g, '') || null;
    }
    booking._hostWhatsApp = hostWhatsApp;
    booking._guestWhatsApp = guestWhatsApp;

    const results = { customer: null, partner: null };

    // ────────── Customer email ──────────
    if (booking.customer_email) {
      results.customer = await sendIdempotent({
        booking_id,
        recipient: booking.customer_email,
        email_type: 'booking_confirmation_customer',
        subject: `Booking confirmed — ${booking.properties.name}`,
        html: customerConfirmationHTML(booking),
        text: customerConfirmationText(booking),
      });
    }

    // ────────── Partner email ──────────
    const partnerEmail = booking.properties?.owner?.email;
    if (partnerEmail) {
      results.partner = await sendIdempotent({
        booking_id,
        recipient: partnerEmail,
        email_type: 'booking_notification_partner',
        subject: `New booking — ${booking.properties.name} (${booking.checkin})`,
        html: partnerNotificationHTML(booking),
        text: partnerNotificationText(booking),
      });
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, results }),
    };
  } catch (err) {
    console.error('send-booking-emails error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: err.message }),
    };
  }
};

// ────────────────────────────────────────────
// Idempotent send: checks email_log, sends, logs result
// ────────────────────────────────────────────
async function sendIdempotent({ booking_id, recipient, email_type, subject, html, text }) {
  // Check if already sent for this booking + type
  const { data: existing } = await supabase
    .from('email_log')
    .select('id, status')
    .eq('booking_id', booking_id)
    .eq('email_type', email_type)
    .maybeSingle();

  if (existing && existing.status === 'sent') {
    return { skipped: true, reason: 'already_sent' };
  }

  try {
    const { data, error } = await resend.emails.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: recipient,
      subject,
      html,
      text,
      reply_to: SUPPORT_EMAIL,
    });
    if (error) throw new Error(error.message || JSON.stringify(error));

    await supabase.from('email_log').upsert({
      booking_id,
      recipient,
      email_type,
      status: 'sent',
      provider_message_id: data?.id || null,
    }, { onConflict: 'booking_id,email_type' });

    return { sent: true, message_id: data?.id };
  } catch (err) {
    await supabase.from('email_log').upsert({
      booking_id,
      recipient,
      email_type,
      status: 'failed',
      error_message: String(err.message || err).slice(0, 500),
    }, { onConflict: 'booking_id,email_type' });
    return { sent: false, error: err.message };
  }
}

// ────────────────────────────────────────────
// Templates — kept inline for now. Easy to extract later.
// Design rules: simple, scannable, mobile-friendly, no images,
// no external CSS (Gmail strips it). Inline styles only.
// ────────────────────────────────────────────

function fmtMoney(n) {
  return `$${Number(n || 0).toFixed(2)}`;
}

function fmtDate(d) {
  if (!d) return '';
  const date = new Date(d + 'T00:00:00');
  return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
}

function fmtTime(t) {
  if (!t) return '';
  const [h, m] = t.split(':');
  let hh = parseInt(h);
  const ampm = hh >= 12 ? 'PM' : 'AM';
  hh = hh % 12 || 12;
  return `${hh}:${m} ${ampm}`;
}

function nights(checkin, checkout) {
  return Math.max(1, Math.round((new Date(checkout) - new Date(checkin)) / 86400000));
}

function escapeHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function emailShell(title, contentHtml) {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>${escapeHtml(title)}</title></head>
<body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px">
<tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">
<tr><td style="padding:24px 28px;background:#0C1A2E;color:#FFFFFF">
<table cellpadding="0" cellspacing="0" border="0"><tr>
<td style="vertical-align:middle;padding-right:12px">
<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 64 64">
<circle cx="32" cy="32" r="26" fill="none" stroke="#22D3EE" stroke-width="3"/>
<path d="M 32 12 L 44 38 L 32 32 L 20 38 Z" fill="#F97316" transform="rotate(35 32 32)"/>
<circle cx="32" cy="32" r="3" fill="#FFFFFF"/>
</svg>
</td>
<td style="vertical-align:middle">
<div style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;font-size:22px;font-weight:800;letter-spacing:-0.5px;color:#FFFFFF">easy<span style="color:#F97316">nomad</span></div>
<div style="font-size:12px;opacity:.7;margin-top:2px;letter-spacing:1.5px;text-transform:uppercase">Stay a while</div>
</td>
</tr></table>
</td></tr>
<tr><td style="padding:28px">
${contentHtml}
</td></tr>
<tr><td style="padding:18px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:12px;color:#64748B">
Questions? Reply to this email or write to <a href="mailto:${SUPPORT_EMAIL}" style="color:#0E7490;text-decoration:none">${SUPPORT_EMAIL}</a><br>
<span style="color:#94A3B8">Ezynomad.com — long-stay homes for travelers worldwide</span>
</td></tr>
</table>
</td></tr>
</table>
</body></html>`;
}

// ───── Customer confirmation ─────
function customerConfirmationHTML(b) {
  const p = b.properties || {};
  const room = b.rooms || { name: 'Standard room' };
  const n = nights(b.checkin, b.checkout);
  const address = p.address_line ? `<div style="margin-top:6px;color:#475569;font-size:14px">${escapeHtml(p.address_line)}</div>` : '';
  const houseRules = p.house_rules ? `
    <div style="margin-top:20px">
      <div style="font-size:13px;font-weight:700;color:#0F172A;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">House rules</div>
      <div style="font-size:14px;color:#334155;white-space:pre-wrap">${escapeHtml(p.house_rules)}</div>
    </div>` : '';

  const content = `
    <div style="font-family:Georgia,serif;font-size:24px;color:#0F172A;margin-bottom:8px">Booking confirmed</div>
    <div style="color:#475569;font-size:15px;margin-bottom:24px">Hi ${escapeHtml(b.customer_name || 'there')}, your stay at <b>${escapeHtml(p.name)}</b> is all set.</div>

    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;border-radius:10px;padding:18px;margin-bottom:18px">
      <tr><td>
        <div style="font-family:Georgia,serif;font-size:18px;color:#0F172A">${escapeHtml(p.name)}</div>
        <div style="color:#64748B;font-size:14px;margin-top:2px">📍 ${escapeHtml(p.city)}, ${escapeHtml(p.country)}</div>
        ${address}
      </td></tr>
    </table>

    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:8px">
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B;width:40%">Check-in</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">
          <b>${fmtDate(b.checkin)}</b>${p.checkin_time ? `<br><span style="color:#64748B;font-size:12px">from ${fmtTime(p.checkin_time)}</span>` : ''}
        </td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Check-out</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">
          <b>${fmtDate(b.checkout)}</b>${p.checkout_time ? `<br><span style="color:#64748B;font-size:12px">by ${fmtTime(p.checkout_time)}</span>` : ''}
        </td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Length of stay</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">${n} night${n > 1 ? 's' : ''}</td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Guests</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">${b.guests}</td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Room</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">${escapeHtml(room.name || 'Standard room')}</td>
      </tr>
      <tr>
        <td style="padding:12px 0 0;font-size:14px;color:#0F172A;font-weight:700">Total paid</td>
        <td style="padding:12px 0 0;font-size:18px;color:#0E7490;text-align:right;font-weight:700">${fmtMoney(b.total_usd)}</td>
      </tr>
    </table>

    ${houseRules}

    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:20px"><tr><td style="padding:14px 16px;background:#F0FDF4;border:1px solid #BBF7D0;border-radius:10px;font-size:13px;color:#15803D">
      <b>💵 Pay at the hotel</b><br>No payment was taken online. Please pay the full amount of ${fmtMoney(b.total_usd)} directly at the property during your stay.
    </td></tr></table>

    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:24px">
      <tr><td align="center">
        <a href="${SITE_URL}/my-bookings" style="display:inline-block;padding:14px 28px;background:#0E7490;color:#FFFFFF;text-decoration:none;border-radius:10px;font-weight:700;font-size:15px">View your booking</a>
      </td></tr>
    </table>

    ${b._hostWhatsApp ? `
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:14px">
      <tr><td align="center">
        <a href="https://wa.me/${b._hostWhatsApp}?text=${encodeURIComponent(`Hi! I just booked ${p.name} (${b.checkin} to ${b.checkout}). Booking reference: ${b.id.slice(0,8).toUpperCase()}. Looking forward to my stay!`)}" style="display:inline-block;padding:14px 28px;background:#25D366;color:#FFFFFF;text-decoration:none;border-radius:10px;font-weight:700;font-size:15px">💬 Contact host on WhatsApp</a>
      </td></tr>
    </table>` : ''}

    <div style="margin-top:24px;padding:14px 16px;background:#FFF7ED;border-radius:10px;font-size:13px;color:#9A3412">
      <b>Booking reference:</b> ${b.id.slice(0, 8).toUpperCase()}<br>
      Save this email. You'll need it at check-in.
    </div>

    <div style="margin-top:24px;font-size:13px;color:#64748B">
      Need to change or cancel? Reply to this email and we'll help.
    </div>
  `;
  return emailShell('Booking confirmed', content);
}

function customerConfirmationText(b) {
  const p = b.properties || {};
  const room = b.rooms || { name: 'Standard room' };
  const n = nights(b.checkin, b.checkout);
  return `Booking confirmed — Ezynomad.com

Hi ${b.customer_name || 'there'},

Your stay at ${p.name} is all set.

${p.name}
${p.city}, ${p.country}${p.address_line ? `\n${p.address_line}` : ''}

Check-in:  ${fmtDate(b.checkin)}${p.checkin_time ? ` (from ${fmtTime(p.checkin_time)})` : ''}
Check-out: ${fmtDate(b.checkout)}${p.checkout_time ? ` (by ${fmtTime(p.checkout_time)})` : ''}
Nights:    ${n}
Guests:    ${b.guests}
Room:      ${room.name || 'Standard room'}
Total:     ${fmtMoney(b.total_usd)}

Booking reference: ${b.id.slice(0, 8).toUpperCase()}

${p.house_rules ? `House rules:\n${p.house_rules}\n\n` : ''}Need help? Reply to this email or write to ${SUPPORT_EMAIL}.
`;
}

// ───── Partner notification ─────
function partnerNotificationHTML(b) {
  const p = b.properties || {};
  const room = b.rooms || { name: 'Standard room' };
  const n = nights(b.checkin, b.checkout);
  const guestPhone = b.customer_phone ? `<br><a href="tel:${escapeHtml(b.customer_phone)}" style="color:#0E7490;text-decoration:none">${escapeHtml(b.customer_phone)}</a>` : '';

  const content = `
    <div style="font-family:Georgia,serif;font-size:24px;color:#0F172A;margin-bottom:8px">New booking received</div>
    <div style="color:#475569;font-size:15px;margin-bottom:24px">A guest just booked <b>${escapeHtml(p.name)}</b>. Details below.</div>

    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#ECFDF5;border:1px solid #10B981;border-radius:10px;padding:16px;margin-bottom:18px">
      <tr><td>
        <div style="font-size:13px;color:#059669;font-weight:700;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">Guest</div>
        <div style="font-size:16px;color:#0F172A;font-weight:700">${escapeHtml(b.customer_name || 'Guest')}</div>
        <div style="font-size:14px;color:#334155;margin-top:4px"><a href="mailto:${escapeHtml(b.customer_email)}" style="color:#0E7490;text-decoration:none">${escapeHtml(b.customer_email)}</a>${guestPhone}</div>
      </td></tr>
    </table>

    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:8px">
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B;width:40%">Check-in</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right"><b>${fmtDate(b.checkin)}</b></td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Check-out</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right"><b>${fmtDate(b.checkout)}</b></td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Nights</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">${n}</td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Guests</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">${b.guests}</td>
      </tr>
      <tr>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:13px;color:#64748B">Room</td>
        <td style="padding:8px 0;border-bottom:1px solid #E2E8F0;font-size:14px;color:#0F172A;text-align:right">${escapeHtml(room.name || 'Standard room')}</td>
      </tr>
      <tr>
        <td style="padding:12px 0 0;font-size:14px;color:#0F172A;font-weight:700">Booking value</td>
        <td style="padding:12px 0 0;font-size:18px;color:#0E7490;text-align:right;font-weight:700">${fmtMoney(b.total_usd)}</td>
      </tr>
    </table>

    ${b._guestWhatsApp ? `
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:24px">
      <tr><td align="center">
        <a href="https://wa.me/${b._guestWhatsApp}?text=${encodeURIComponent(`Hi ${(b.customer_name || '').split(' ')[0] || 'there'}, this is ${p.name}. Thanks for booking with us! We've received your reservation for ${b.checkin} to ${b.checkout}. Booking ref: ${b.id.slice(0,8).toUpperCase()}. Let us know if you have any questions before arrival.`)}" style="display:inline-block;padding:14px 28px;background:#25D366;color:#FFFFFF;text-decoration:none;border-radius:10px;font-weight:700;font-size:15px">💬 Message guest on WhatsApp</a>
      </td></tr>
    </table>` : ''}

    <div style="margin-top:24px;padding:14px 16px;background:#F8FAFC;border-radius:10px;font-size:13px;color:#334155">
      <b>Booking ref:</b> ${b.id.slice(0, 8).toUpperCase()}<br>
      Log in to your partner console to see this booking and prepare for arrival.
    </div>
  `;
  return emailShell('New booking received', content);
}

function partnerNotificationText(b) {
  const p = b.properties || {};
  const room = b.rooms || { name: 'Standard room' };
  const n = nights(b.checkin, b.checkout);
  return `New booking received — Ezynomad.com

A guest just booked ${p.name}.

Guest:    ${b.customer_name || 'Guest'}
Email:    ${b.customer_email}${b.customer_phone ? `\nPhone:    ${b.customer_phone}` : ''}

Check-in: ${fmtDate(b.checkin)}
Check-out:${fmtDate(b.checkout)}
Nights:   ${n}
Guests:   ${b.guests}
Room:     ${room.name || 'Standard room'}
Value:    ${fmtMoney(b.total_usd)}

Booking ref: ${b.id.slice(0, 8).toUpperCase()}

Log in to your partner console at https://ezynomad.com to prepare for arrival.
`;
}
