// netlify/functions/stripe-webhook.js
// Listens for Stripe payment events. When a payment succeeds, marks the booking
// confirmed and creates a pending payout row for the property owner.

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

exports.handler = async (event) => {
  const sig = event.headers['stripe-signature'];
  let stripeEvent;
  try {
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }

  if (stripeEvent.type === 'payment_intent.succeeded') {
    const pi = stripeEvent.data.object;
    const bookingId = pi.metadata.booking_id;

    // Confirm the booking
    await supabase.from('bookings').update({ status: 'confirmed' }).eq('id', bookingId);

    // Get the property owner and calculate net payout (90% of total)
    const { data: booking } = await supabase
      .from('bookings')
      .select('total_usd, property_id')
      .eq('id', bookingId)
      .single();

    if (booking) {
      const { data: property } = await supabase
        .from('properties')
        .select('owner_id')
        .eq('id', booking.property_id)
        .single();

      if (property) {
        await supabase.from('payouts').insert({
          owner_id: property.owner_id,
          booking_id: bookingId,
          amount_usd: booking.total_usd * 0.9,
          status: 'pending'
        });
      }
    }
  }

  if (stripeEvent.type === 'payment_intent.payment_failed') {
    const pi = stripeEvent.data.object;
    await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .eq('id', pi.metadata.booking_id);
  }

  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
