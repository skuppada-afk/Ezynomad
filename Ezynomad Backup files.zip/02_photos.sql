-- ═══════════════════════════════════════════════════════════
-- PHOTOS MIGRATION
-- Run this in Supabase SQL Editor
-- ═══════════════════════════════════════════════════════════

-- 1. Add a photos column to the properties table (array of URLs)
alter table public.properties
  add column if not exists photos text[] default '{}';

-- 2. Create the storage bucket for property photos
insert into storage.buckets (id, name, public)
values ('property-photos', 'property-photos', true)
on conflict (id) do nothing;

-- 3. Storage policies: anyone can VIEW photos (since bucket is public),
--    but only authenticated users can upload, and only into their own folder.

-- Allow anyone (even logged out) to read photos
create policy "Public can view property photos"
  on storage.objects for select
  using (bucket_id = 'property-photos');

-- Authenticated users can upload to property-photos
create policy "Authenticated can upload property photos"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'property-photos');

-- Authenticated users can update/delete their own files
create policy "Authenticated can update own property photos"
  on storage.objects for update
  to authenticated
  using (bucket_id = 'property-photos' and owner = auth.uid());

create policy "Authenticated can delete own property photos"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'property-photos' and owner = auth.uid());
