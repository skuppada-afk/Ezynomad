-- ═══════════════════════════════════════════════════════════
-- MIGRATION 15 — AVAILABILITY BLOCKS
-- Lets partners manually block rooms on specific dates
-- (maintenance, owner use, offline bookings, etc).
-- Booked rooms come from the bookings table; this table is
-- only for MANUAL blocks on top of that.
-- ═══════════════════════════════════════════════════════════

create table if not exists public.availability_blocks (
  id uuid primary key default gen_random_uuid(),
  property_id uuid not null references public.properties(id) on delete cascade,
  blocked_date date not null,
  rooms_blocked integer not null default 1,
  note text,
  created_by uuid references auth.users(id),
  created_at timestamptz default now(),
  unique (property_id, blocked_date)
);

create index if not exists availability_blocks_property_idx
  on public.availability_blocks (property_id, blocked_date);

alter table public.availability_blocks enable row level security;

-- Anyone can read blocks (needed for the public booking availability check)
drop policy if exists "anyone can read availability blocks" on public.availability_blocks;
create policy "anyone can read availability blocks"
  on public.availability_blocks
  for select
  to authenticated, anon
  using (true);

-- Only the property owner or an admin can write blocks
drop policy if exists "owner manages availability blocks" on public.availability_blocks;
create policy "owner manages availability blocks"
  on public.availability_blocks
  for all
  to authenticated
  using (
    exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  )
  with check (
    exists (select 1 from public.properties p where p.id = property_id and p.owner_id = auth.uid())
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );
