-- ═══════════════════════════════════════════════════════════
-- EASYNOMAD.WORLD — SUPABASE DATABASE SCHEMA
-- Run this entire file in Supabase SQL Editor in one go
-- ═══════════════════════════════════════════════════════════

-- 1. PROFILES (extends auth.users)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  full_name text,
  email text unique,
  role text default 'customer' check (role in ('customer','partner','admin')),
  stripe_account_id text,
  stripe_onboarded boolean default false,
  created_at timestamptz default now()
);

-- 2. PROPERTIES
create table if not exists public.properties (
  id uuid default gen_random_uuid() primary key,
  owner_id uuid references public.profiles(id) on delete cascade,
  name text not null,
  city text not null,
  country text not null,
  type text default 'hostel',
  description text,
  amenities text,
  price_usd numeric(10,2) not null,
  emoji text default '🏨',
  badge text,
  rating numeric(3,1),
  total_rooms integer default 5,
  status text default 'active' check (status in ('active','suspended','draft')),
  created_at timestamptz default now()
);

-- 3. ROOMS (optional room types per property)
create table if not exists public.rooms (
  id uuid default gen_random_uuid() primary key,
  property_id uuid references public.properties(id) on delete cascade,
  name text not null,
  price_usd numeric(10,2) not null,
  beds text,
  features text,
  total_units integer default 1,
  created_at timestamptz default now()
);

-- 4. BOOKINGS
create table if not exists public.bookings (
  id uuid default gen_random_uuid() primary key,
  customer_id uuid references public.profiles(id),
  property_id uuid references public.properties(id),
  room_id uuid,
  checkin date not null,
  checkout date not null,
  guests integer default 1,
  subtotal_usd numeric(10,2),
  fee_usd numeric(10,2),
  total_usd numeric(10,2),
  status text default 'pending' check (status in ('pending','confirmed','cancelled','refunded')),
  stripe_payment_intent_id text,
  customer_email text,
  customer_name text,
  customer_phone text,
  created_at timestamptz default now()
);

-- 5. PAYOUTS
create table if not exists public.payouts (
  id uuid default gen_random_uuid() primary key,
  owner_id uuid references public.profiles(id),
  booking_id uuid references public.bookings(id),
  amount_usd numeric(10,2),
  status text default 'pending' check (status in ('pending','paid','failed')),
  stripe_transfer_id text,
  created_at timestamptz default now(),
  paid_at timestamptz
);

-- 6. SITE CONTENT (for admin to edit homepage copy)
create table if not exists public.site_content (
  id integer primary key default 1,
  hero_eyebrow text default 'Easynomad.world',
  hero_headline text default 'Stays built for nomads, not tourists',
  hero_subheadline text default 'Hostels, boutique hotels, and villas across Southeast Asia. Tested WiFi. Real reviews.',
  updated_at timestamptz default now(),
  constraint single_row check (id = 1)
);

insert into public.site_content (id) values (1) on conflict (id) do nothing;

-- ═══════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════════════════

alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.rooms enable row level security;
alter table public.bookings enable row level security;
alter table public.payouts enable row level security;
alter table public.site_content enable row level security;

-- PROFILES policies
create policy "Profiles are viewable by everyone"
  on public.profiles for select using (true);
create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);
create policy "Users can insert own profile"
  on public.profiles for insert with check (auth.uid() = id);

-- PROPERTIES policies
create policy "Active properties are viewable by everyone"
  on public.properties for select using (status = 'active' or owner_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));
create policy "Owners can insert their properties"
  on public.properties for insert with check (owner_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));
create policy "Owners can update their properties"
  on public.properties for update using (owner_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

-- ROOMS policies
create policy "Rooms are viewable by everyone"
  on public.rooms for select using (true);
create policy "Property owners can manage rooms"
  on public.rooms for all using (
    exists (select 1 from public.properties where id = property_id and (owner_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')))
  );

-- BOOKINGS policies
create policy "Customers see own bookings"
  on public.bookings for select using (
    customer_id = auth.uid()
    or exists (select 1 from public.properties where id = property_id and owner_id = auth.uid())
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );
create policy "Authenticated users can create bookings"
  on public.bookings for insert with check (auth.uid() is not null);
create policy "Admins can update bookings"
  on public.bookings for update using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- PAYOUTS policies
create policy "Owners see own payouts"
  on public.payouts for select using (
    owner_id = auth.uid()
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- SITE_CONTENT policies
create policy "Anyone can read site content"
  on public.site_content for select using (true);
create policy "Only admins can update site content"
  on public.site_content for update using (
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- ═══════════════════════════════════════════════════════════
-- MANUAL: After signing up your first user, run this to make
-- yourself admin. Replace the email with yours.
-- ═══════════════════════════════════════════════════════════
-- update public.profiles set role = 'admin' where email = 'your@email.com';
