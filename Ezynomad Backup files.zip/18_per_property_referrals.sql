-- ═══════════════════════════════════════════════════════════
-- MIGRATION 18 — PER-PROPERTY REFERRAL BOUNTIES
-- Changes the referral program from one bounty per referred host
-- to one bounty per property a referred host lists.
--
-- Model: each referral row now represents ONE property.
--   - The original "invited" row (property_id is null) qualifies
--     for the referee's FIRST property.
--   - Each ADDITIONAL property by the same referee inserts a NEW
--     qualified referral row, copying referrer + referee details.
--   - Keyed on property_id, so a given property earns exactly once,
--     even if it is delisted and relisted.
-- ═══════════════════════════════════════════════════════════

-- 1. Drop the one-row-per-(referrer,email) constraint.
--    We now allow multiple rows per referee, one per property.
alter table public.referrals
  drop constraint if exists referrals_referrer_id_referee_email_key;

-- 2. Stop two rows ever pointing at the same property.
--    (partial unique index - ignores the null-property invited rows)
create unique index if not exists referrals_property_unique
  on public.referrals (property_id)
  where property_id is not null;

-- 3. Rewrite the auto-qualification trigger for per-property logic.
create or replace function public.auto_qualify_referral()
returns trigger
language plpgsql
security definer
as $$
declare
  v_referee_email text;
  v_existing_for_property uuid;
  v_open_invite public.referrals%rowtype;
begin
  -- Only act when a property becomes active
  if not (
    (TG_OP = 'INSERT' and NEW.status = 'active') or
    (TG_OP = 'UPDATE' and NEW.status = 'active' and (OLD.status is null or OLD.status != 'active'))
  ) then
    return NEW;
  end if;

  -- Who owns this property?
  select lower(email) into v_referee_email
  from public.profiles where id = NEW.owner_id;
  if v_referee_email is null then
    return NEW;
  end if;

  -- This property already has a referral row? Then it has already
  -- earned its bounty. Do nothing (prevents relisting from re-earning).
  select id into v_existing_for_property
  from public.referrals where property_id = NEW.id limit 1;
  if v_existing_for_property is not null then
    return NEW;
  end if;

  -- Is there an open "invited" referral for this owner with no property yet?
  -- If so, use it for THIS property (the referee's first listing).
  select * into v_open_invite
  from public.referrals
  where status = 'invited'
    and property_id is null
    and lower(referee_email) = v_referee_email
  order by created_at asc
  limit 1;

  if v_open_invite.id is not null then
    update public.referrals
    set status = 'qualified',
        qualified_at = now(),
        referee_user_id = NEW.owner_id,
        property_id = NEW.id
    where id = v_open_invite.id;
    return NEW;
  end if;

  -- No open invite. But the owner may have been referred before and
  -- already qualified for an earlier property. If ANY referral exists
  -- for this referee, clone it for this additional property so the
  -- referrer earns another bounty.
  insert into public.referrals
    (referrer_id, referee_email, referee_name, referee_phone, referee_whatsapp,
     referee_user_id, property_id, note, status, bounty_usd, qualified_at)
  select
    r.referrer_id, r.referee_email, r.referee_name, r.referee_phone, r.referee_whatsapp,
    NEW.owner_id, NEW.id,
    'Additional property by the same referred host',
    'qualified', coalesce(r.bounty_usd, 5), now()
  from public.referrals r
  where lower(r.referee_email) = v_referee_email
  order by r.created_at asc
  limit 1;

  return NEW;
end;
$$;

drop trigger if exists trg_auto_qualify_referral on public.properties;
create trigger trg_auto_qualify_referral
  after insert or update on public.properties
  for each row
  execute function public.auto_qualify_referral();
