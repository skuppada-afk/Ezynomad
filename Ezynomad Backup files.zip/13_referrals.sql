-- ═══════════════════════════════════════════════════════════
-- MIGRATION 13 — REFERRALS PROGRAM
-- A simple attribution + manual payout tracker. No payment processing.
-- Admin marks referrals as paid out-of-band.
-- ═══════════════════════════════════════════════════════════

-- 1. Referrals: tracks who referred whom
create table if not exists public.referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references public.profiles(id) on delete cascade,
  referee_email text not null,
  referee_name text,
  referee_phone text,
  referee_whatsapp text,
  referee_user_id uuid references public.profiles(id), -- set when invite is accepted
  property_id uuid references public.properties(id),    -- set when first property published
  note text,                                            -- optional context from referrer
  status text not null default 'invited',               -- invited | qualified | paid | ineligible
  bounty_inr numeric default 500,                       -- ₹500 per the policy
  created_at timestamptz default now(),
  qualified_at timestamptz,
  ineligible_reason text,
  unique (referrer_id, referee_email)                   -- one referral per pair
);

create index if not exists referrals_referrer_idx on public.referrals (referrer_id, status, created_at desc);
create index if not exists referrals_status_idx on public.referrals (status, qualified_at desc nulls last);
create index if not exists referrals_email_idx on public.referrals (referee_email);

-- 2. Payouts: tracks actual payment events, manually recorded by admin
create table if not exists public.referral_payouts (
  id uuid primary key default gen_random_uuid(),
  referral_id uuid not null references public.referrals(id) on delete restrict,
  amount_inr numeric not null,
  payee_name text not null,
  payee_account_number text,
  payee_ifsc text,           -- Indian bank routing
  payee_swift text,          -- international wire
  payee_bank_name text,
  payee_country text,
  payment_reference text,    -- UTR / transaction ID after payment is sent
  payment_method text,       -- bank-transfer | upi | other
  payment_note text,
  paid_at timestamptz default now(),
  paid_by uuid references auth.users(id),
  created_at timestamptz default now()
);

create index if not exists referral_payouts_referral_idx on public.referral_payouts (referral_id);
create index if not exists referral_payouts_paid_at_idx on public.referral_payouts (paid_at desc);

-- 3. Referrer bank details: stored once per referrer, used at payout time
create table if not exists public.referrer_bank_details (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  payee_name text,
  account_number text,
  ifsc text,
  swift text,
  bank_name text,
  country text,
  payment_method text default 'bank-transfer',
  updated_at timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- AUTO-QUALIFICATION TRIGGER
-- When a property goes live (status = 'active'), check whether
-- the owner was referred. If yes and referral is still 'invited',
-- flip to 'qualified' and stamp qualified_at.
-- ═══════════════════════════════════════════════════════════

create or replace function public.auto_qualify_referral()
returns trigger
language plpgsql
security definer
as $$
begin
  -- Only act when a property transitions to active
  if (TG_OP = 'INSERT' and NEW.status = 'active') or
     (TG_OP = 'UPDATE' and NEW.status = 'active' and (OLD.status is null or OLD.status != 'active')) then
    update public.referrals
    set status = 'qualified',
        qualified_at = now(),
        referee_user_id = NEW.owner_id,
        property_id = NEW.id
    where referee_user_id is null
      and status = 'invited'
      and lower(referee_email) = (
        select lower(email) from public.profiles where id = NEW.owner_id
      );
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_auto_qualify_referral on public.properties;
create trigger trg_auto_qualify_referral
  after insert or update on public.properties
  for each row
  execute function public.auto_qualify_referral();

-- ═══════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════════════════

alter table public.referrals enable row level security;
alter table public.referral_payouts enable row level security;
alter table public.referrer_bank_details enable row level security;

-- Referrals: a user can see their own + admin sees all
drop policy if exists "users see own referrals" on public.referrals;
create policy "users see own referrals" on public.referrals
  for select to authenticated
  using (
    referrer_id = auth.uid()
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Only authenticated users can create referrals (their own only)
drop policy if exists "users create own referrals" on public.referrals;
create policy "users create own referrals" on public.referrals
  for insert to authenticated
  with check (referrer_id = auth.uid());

-- Only admins update referrals
drop policy if exists "admins update referrals" on public.referrals;
create policy "admins update referrals" on public.referrals
  for update to authenticated
  using (exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

-- Payouts: visible to admin only (and the referrer for their own)
drop policy if exists "users see own payouts" on public.referral_payouts;
create policy "users see own payouts" on public.referral_payouts
  for select to authenticated
  using (
    exists (select 1 from public.referrals where id = referral_id and referrer_id = auth.uid())
    or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Only admins write payouts
drop policy if exists "admins write payouts" on public.referral_payouts;
create policy "admins write payouts" on public.referral_payouts
  for all to authenticated
  using (exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'))
  with check (exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));

-- Bank details: user owns their own
drop policy if exists "users manage own bank details" on public.referrer_bank_details;
create policy "users manage own bank details" on public.referrer_bank_details
  for all to authenticated
  using (user_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'))
  with check (user_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'));
