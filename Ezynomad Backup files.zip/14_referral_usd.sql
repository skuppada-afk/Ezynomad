-- ═══════════════════════════════════════════════════════════
-- MIGRATION 14 — REFERRAL BOUNTY TO USD
-- Switches the referral program from INR ₹500 to USD $5.
-- ═══════════════════════════════════════════════════════════

-- Rename and re-default the referrals bounty column
alter table public.referrals rename column bounty_inr to bounty_usd;
alter table public.referrals alter column bounty_usd set default 5;
update public.referrals set bounty_usd = 5 where bounty_usd = 500;

-- Rename the payout amount column
alter table public.referral_payouts rename column amount_inr to amount_usd;
