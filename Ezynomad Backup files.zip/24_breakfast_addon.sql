-- ═══════════════════════════════════════════════════════════
-- MIGRATION 24 — BREAKFAST ADD-ON
-- Partners can set an optional breakfast price (per guest,
-- per night). Customers can opt in when booking.
-- ═══════════════════════════════════════════════════════════

-- Partner sets this on the property
alter table public.properties
  add column if not exists breakfast_price_usd numeric(10,2);

-- Recorded on the booking when the guest opts in
alter table public.bookings
  add column if not exists breakfast_included boolean default false,
  add column if not exists breakfast_cost_usd numeric(10,2) default 0;
