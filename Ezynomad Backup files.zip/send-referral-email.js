// Netlify function: sends a friendly thank-you / welcome email to a referee
// when someone refers them to list a property on Ezynomad.

const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME = 'Ezynomad';
const SITE_URL = process.env.SITE_URL || 'https://ezynomad.com';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    console.log('[referral-email] body received:', event.body);
    const { referee_email, referee_name, referrer_name } = JSON.parse(event.body || '{}');
    console.log('[referral-email] parsed:', { referee_email, referee_name, referrer_name });
    console.log('[referral-email] FROM_EMAIL:', FROM_EMAIL, 'has API key:', !!process.env.RESEND_API_KEY);
    if (!referee_email) {
      console.log('[referral-email] missing referee_email, returning 400');
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'referee_email required' }) };
    }

    const name = referee_name || 'there';
    const referrer = referrer_name || 'a friend';

    const html = `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">
<tr><td style="padding:24px 28px;background:#0C1A2E;color:#FFFFFF">
<div style="font-size:13px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">You've been invited</div>
<div style="font-size:21px;font-weight:700">Welcome to Ezynomad</div>
</td></tr>
<tr><td style="padding:28px">
<div style="font-size:15px;color:#0F172A;margin-bottom:14px">Hi ${escapeHtml(name)},</div>
<div style="font-size:15px;color:#475569;margin-bottom:14px">${escapeHtml(referrer)} thought your property would be a great fit for Ezynomad, a marketplace for long-stay travellers and digital nomads looking for places that feel like home.</div>
<div style="font-size:15px;color:#475569;margin-bottom:18px">Listing is free. You keep 100% of your nightly rate, you get direct contact with guests, and there are no monthly fees. We just add a small service fee that guests pay.</div>
<div style="text-align:center;margin:24px 0">
<a href="${SITE_URL}/signup" style="display:inline-block;padding:13px 30px;background:#0E7490;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;font-size:15px">List your property</a>
</div>
<div style="font-size:13px;color:#64748B">Questions? Just reply to this email or write to support@ezynomad.com. We'd love to have you.</div>
</td></tr>
<tr><td style="padding:16px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">Ezynomad.com — long-stay homes for travellers</td></tr>
</table></td></tr></table></body></html>`;

    const text = `Hi ${name},

${referrer} thought your property would be a great fit for Ezynomad, a marketplace for long-stay travellers and digital nomads.

Listing is free. You keep 100% of your nightly rate and get direct contact with guests. No monthly fees.

List your property: ${SITE_URL}/signup

Questions? Reply to this email or write to support@ezynomad.com.`;

    console.log('[referral-email] calling Resend with from:', `${FROM_NAME} <${FROM_EMAIL}>`, 'to:', referee_email);
    const r = await resend.emails.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: referee_email,
      subject: `${referrer} invited you to list on Ezynomad`,
      html,
      text,
    });
    console.log('[referral-email] Resend response:', JSON.stringify(r));

    if (r.error) {
      console.log('[referral-email] Resend returned error:', r.error.message);
      return { statusCode: 502, headers: corsHeaders, body: JSON.stringify({ error: r.error.message }) };
    }
    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true }),
    };
  } catch (err) {
    console.error('send-referral-email error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};
