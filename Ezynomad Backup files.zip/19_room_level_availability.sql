-- ═══════════════════════════════════════════════════════════
-- MIGRATION 19 — ROOM-LEVEL AVAILABILITY BLOCKS
-- Lets partners block a SPECIFIC room type on a date,
-- e.g. close "Pool View" for today while other rooms stay open.
--
-- room_id NULL  = block applies to the whole property (legacy behaviour)
-- room_id SET   = block applies only to that room type
-- ═══════════════════════════════════════════════════════════

-- 1. Add the optional room reference
alter table public.availability_blocks
  add column if not exists room_id uuid references public.rooms(id) on delete cascade;

-- 2. The old unique constraint was (property_id, blocked_date) - one block per
--    property per day. With per-room blocks we need one block per
--    (property, room, date). Drop the old constraint, add the new one.
alter table public.availability_blocks
  drop constraint if exists availability_blocks_property_id_blocked_date_key;

-- A partial unique index for property-wide blocks (room_id is null)
create unique index if not exists availability_blocks_property_date_unique
  on public.availability_blocks (property_id, blocked_date)
  where room_id is null;

-- A unique index for per-room blocks (room_id is set)
create unique index if not exists availability_blocks_room_date_unique
  on public.availability_blocks (property_id, room_id, blocked_date)
  where room_id is not null;

-- 3. Helpful index for lookups by room
create index if not exists availability_blocks_room_idx
  on public.availability_blocks (room_id, blocked_date);
