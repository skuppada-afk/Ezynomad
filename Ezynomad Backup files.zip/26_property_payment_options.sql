-- ═══════════════════════════════════════════════════════════
-- MIGRATION 26 — PROPERTY PAYMENT OPTIONS
-- A partner chooses which payment methods their property accepts.
--   'both'     - guest chooses online or pay at property (default)
--   'property' - pay at the property only
--   'online'   - pay online only
-- ═══════════════════════════════════════════════════════════

alter table public.properties
  add column if not exists payment_options text default 'both';
