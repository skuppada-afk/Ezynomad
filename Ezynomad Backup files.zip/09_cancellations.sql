-- ═══════════════════════════════════════════════════════════
-- MIGRATION 09 — BOOKING CANCELLATION TRACKING
-- Adds columns to track who cancelled, why, when, and any note
-- explaining the cancellation for the customer.
-- ═══════════════════════════════════════════════════════════

alter table public.bookings
  add column if not exists cancellation_reason text,
  add column if not exists cancellation_note text,
  add column if not exists cancelled_at timestamptz,
  add column if not exists cancelled_by uuid references auth.users(id);

-- Helpful index for filtering recent cancellations in admin views
create index if not exists bookings_cancelled_at_idx on public.bookings (cancelled_at desc) where status = 'cancelled';
