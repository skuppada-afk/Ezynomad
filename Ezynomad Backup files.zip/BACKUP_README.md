# Ezynomad.com — Project Backup (May 20, 2026)

A complete snapshot of the codebase as of the brand migration from
easynomad.world to ezynomad.com.

## How the project is organized on the live server

```
~/Desktop/easynomad-project/         (root)
├── index.html                       (the entire frontend, single file)
├── netlify.toml                     (Netlify config)
├── netlify-functions/               (serverless backend)
│   ├── invite-user.js
│   ├── razorpay-create-order.js
│   ├── razorpay-verify-payment.js
│   ├── send-booking-emails.js
│   ├── send-cancellation-email.js
│   ├── send-feedback-email.js
│   ├── send-referral-email.js
│   ├── send-referral-payout-email.js
│   ├── send-referrer-confirmation.js
│   ├── connect-stripe.js            (legacy, not actively used)
│   ├── create-payment-intent.js     (legacy, not actively used)
│   ├── stripe-webhook.js            (legacy, not actively used)
│   └── package.json
└── sql/                             (Supabase migrations, run in order)
    ├── 01_initial_schema.sql
    └── ... through 30_referral_country_property.sql
```

To restore from this backup, copy index.html and netlify.toml into the
project root, the .js files into netlify-functions/, and (only if rebuilding
the database) the .sql files run in numeric order on Supabase.

## Infrastructure (NOT in this backup, must be reconfigured separately)

These run in third-party services and need to be set up at the dashboards,
they aren't files you can back up:

- Supabase project (database, auth, storage)
- Resend (email domain verification on ezynomad.com)
- Netlify env vars: RESEND_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_KEY,
  FROM_EMAIL, SUPPORT_EMAIL, SITE_URL, RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
- Netlify domain config: ezynomad.com (primary), easynomad.world (alias)
- GoDaddy DNS for ezynomad.com (A record 75.2.60.5, MX, SPF, DKIM, DMARC)
- Razorpay (live keys, account activation)
- Google OAuth for Supabase auth

## Key technical decisions and patterns

- USD is the canonical stored currency; frontend converts for display.
- Customer bookings work both logged-in and guest (customer_id may be null).
- Room photos stored in property-photos Supabase bucket.
- Referrals work without login; referrer_id is null until they register
  (auto-linked on signup by linkPendingReferrals).
- Email send-from address: support@ezynomad.com (verified in Resend).
- Online payment via Razorpay; pay-at-property is the fallback and works
  for everyone with no setup.

## What was working as of this backup

- Booking flow (guest + logged-in, both payment methods)
- Property listing form with room types, photos, payment options
- Per-property referrals with bounty
- Open referral form (no login required)
- Cancellation flow with policy enforcement
- Admin console
- Email pipeline (Resend) end-to-end with SPF/DKIM/DMARC correct

## What was still pending as of this backup

- ezynomad.com SSL certificate (waiting on Let's Encrypt rate-limit cooldown,
  should self-resolve within 24-48 hours of May 20)
- Active customer acquisition / distribution
