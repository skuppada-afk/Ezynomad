// Netlify function: sends a confirmation email to the REFERRER after they
// submit a referral. Encourages them to register/login to track status.

const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME = 'Ezynomad';
const SITE_URL = process.env.SITE_URL || 'https://ezynomad.com';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const {
      referrer_email,
      referrer_name,
      referee_name,
      referee_property_name,
      is_logged_in,
    } = JSON.parse(event.body || '{}');

    if (!referrer_email) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'referrer_email required' }) };
    }

    const yourName = referrer_name || 'there';
    const propertyText = referee_property_name
      ? `${escapeHtml(referee_property_name)} (contact: ${escapeHtml(referee_name || 'the property owner')})`
      : escapeHtml(referee_name || 'the property owner');

    // Logged-in users see "View my referrals", guests see "Register to track"
    const ctaLabel = is_logged_in ? 'View my referrals' : 'Register to track my referral';
    const ctaUrl = is_logged_in ? `${SITE_URL}/my-referrals` : `${SITE_URL}/signup`;

    const html = `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">
<tr><td style="padding:24px 28px;background:#0C1A2E;color:#FFFFFF">
<div style="font-size:13px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">Referral received</div>
<div style="font-size:21px;font-weight:700">Thanks for the referral${yourName !== 'there' ? ', ' + escapeHtml(yourName) : ''}!</div>
</td></tr>
<tr><td style="padding:28px">
<div style="font-size:15px;color:#0F172A;margin-bottom:14px">Hi ${escapeHtml(yourName)},</div>
<div style="font-size:15px;color:#475569;margin-bottom:14px">We've received your referral for <b>${propertyText}</b>. They'll receive a friendly invitation from us shortly.</div>
<div style="background:#F0FDF4;border-left:4px solid #16A34A;border-radius:6px;padding:14px 16px;margin:18px 0;font-size:14px;color:#166534">
<b>How your $5 works</b><br>
<span style="color:#15803D">1. They list an active property on Ezynomad<br>2. Your referral turns to "qualified"<br>3. You receive $5 (per property listed)</span>
</div>
${is_logged_in
  ? `<div style="font-size:15px;color:#475569;margin-bottom:18px">You can view this referral's status any time on your dashboard.</div>`
  : `<div style="font-size:15px;color:#475569;margin-bottom:18px"><b>Register to track this referral.</b> Create a free account with this email address (${escapeHtml(referrer_email)}) and we'll automatically link your referrals to your account so you can see status and rewards.</div>`
}
<div style="text-align:center;margin:22px 0 8px">
<a href="${ctaUrl}" style="display:inline-block;padding:13px 30px;background:#0E7490;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;font-size:15px">${escapeHtml(ctaLabel)}</a>
</div>
<div style="font-size:13px;color:#64748B;margin-top:18px">Questions? Just reply to this email or write to support@ezynomad.com.</div>
</td></tr>
<tr><td style="padding:16px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">Ezynomad.com — long-stay homes for travellers</td></tr>
</table></td></tr></table></body></html>`;

    const text = `Hi ${yourName},

Thanks for the referral! We've received your referral for ${referee_property_name || referee_name || 'the property owner'}. They'll receive a friendly invitation from us shortly.

How your $5 works:
1. They list an active property on Ezynomad
2. Your referral turns to "qualified"
3. You receive $5 (per property listed)

${is_logged_in
  ? 'View your referrals at any time: ' + SITE_URL + '/my-referrals'
  : 'Register to track this referral. Create a free account with this email (' + referrer_email + ') and we will automatically link your referrals to your account.\n\nRegister: ' + SITE_URL + '/signup'
}

Questions? Reply to this email or write to support@ezynomad.com.`;

    const r = await resend.emails.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: referrer_email,
      subject: `Thanks for referring ${referee_property_name || referee_name || 'a property'} to Ezynomad`,
      html,
      text,
    });

    if (r.error) {
      console.log('[referrer-confirmation] Resend error:', r.error.message);
      return { statusCode: 502, headers: corsHeaders, body: JSON.stringify({ error: r.error.message }) };
    }
    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true }),
    };
  } catch (err) {
    console.error('send-referrer-confirmation error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};
