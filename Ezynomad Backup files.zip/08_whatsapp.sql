-- ═══════════════════════════════════════════════════════════
-- MIGRATION 08 — WHATSAPP CONTACT
-- Adds whatsapp column to profiles. Separate from phone so users
-- can have different numbers for calls vs messaging.
-- ═══════════════════════════════════════════════════════════

alter table public.profiles
  add column if not exists whatsapp text;
