-- ═══════════════════════════════════════════════════════════
-- MIGRATION 06 — ADDRESS, DISCOUNTS, HOUSE RULES
-- Adds: full street address, long-stay discount tiers, house rules.
-- Safe to run multiple times.
-- ═══════════════════════════════════════════════════════════

alter table public.properties
  add column if not exists address_line text,
  add column if not exists discount_weekly_pct numeric(5,2),
  add column if not exists discount_monthly_pct numeric(5,2),
  add column if not exists checkin_time text,
  add column if not exists checkout_time text,
  add column if not exists house_rules text;

-- Sanity-check discount values stay in 0-100 range
alter table public.properties
  drop constraint if exists discount_weekly_range;
alter table public.properties
  add constraint discount_weekly_range
  check (discount_weekly_pct is null or (discount_weekly_pct >= 0 and discount_weekly_pct <= 100));

alter table public.properties
  drop constraint if exists discount_monthly_range;
alter table public.properties
  add constraint discount_monthly_range
  check (discount_monthly_pct is null or (discount_monthly_pct >= 0 and discount_monthly_pct <= 100));

-- No RLS changes needed; existing policies on properties cover these columns.
