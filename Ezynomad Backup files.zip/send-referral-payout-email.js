// Netlify function: sends a payout confirmation email to a referrer
// after an admin records a referral payout. Confirms their bounty was paid.
// Called by the frontend after a referral_payouts row is inserted.

const { createClient } = require('@supabase/supabase-js');
const { Resend } = require('resend');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);
const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME = 'Ezynomad';
const SITE_URL = process.env.SITE_URL || 'https://ezynomad.com';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const { referral_id, amount_usd, payment_reference } = JSON.parse(event.body || '{}');
    if (!referral_id) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'referral_id required' }) };
    }

    // Look up the referral
    const { data: referral, error: rErr } = await supabase
      .from('referrals')
      .select('referrer_id, referee_name, referee_email')
      .eq('id', referral_id)
      .maybeSingle();
    if (rErr || !referral) {
      return { statusCode: 404, headers: corsHeaders, body: JSON.stringify({ error: 'Referral not found' }) };
    }

    // Look up the referrer's email and name
    const { data: referrer } = await supabase
      .from('profiles')
      .select('email, full_name')
      .eq('id', referral.referrer_id)
      .maybeSingle();

    if (!referrer?.email) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Referrer has no email on file' }) };
    }

    const amount = amount_usd ? `$${Number(amount_usd).toFixed(2)}` : '$5.00';
    const referrerName = referrer.full_name || 'there';
    const refereeName = referral.referee_name || 'your referral';

    const r = await resend.emails.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: referrer.email,
      subject: `Your ${amount} referral reward has been paid`,
      html: payoutHTML(referrerName, refereeName, amount, payment_reference),
      text: payoutText(referrerName, refereeName, amount, payment_reference),
    });

    if (r.error) {
      return { statusCode: 502, headers: corsHeaders, body: JSON.stringify({ error: r.error.message }) };
    }

    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true }),
    };
  } catch (err) {
    console.error('send-referral-payout-email error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};

function payoutHTML(referrerName, refereeName, amount, reference) {
  return `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:560px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">
<tr><td style="padding:26px 28px;background:#15803D;color:#FFFFFF">
<div style="font-size:13px;opacity:.8;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">Referral reward paid</div>
<div style="font-size:24px;font-weight:700">${escapeHtml(amount)} is on its way to you</div>
</td></tr>
<tr><td style="padding:28px">
<div style="font-size:16px;margin-bottom:14px">Hi ${escapeHtml(referrerName)},</div>
<div style="font-size:15px;color:#475569;margin-bottom:16px">Good news. The referral reward for bringing <b>${escapeHtml(refereeName)}</b> to Ezynomad has been paid out. Thank you for helping the community grow.</div>
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:10px;margin-bottom:20px"><tr><td style="padding:16px 18px;font-size:14px;color:#166534">
<div style="padding:3px 0"><span style="color:#15803D">Amount paid:</span> <b>${escapeHtml(amount)}</b></div>
<div style="padding:3px 0"><span style="color:#15803D">For referring:</span> ${escapeHtml(refereeName)}</div>
${reference ? `<div style="padding:3px 0"><span style="color:#15803D">Payment reference:</span> ${escapeHtml(reference)}</div>` : ''}
</td></tr></table>
<div style="font-size:14px;color:#475569;margin-bottom:18px">Know another great property owner? Keep referring and keep earning.</div>
<div style="text-align:center">
<a href="${SITE_URL}/refer" style="display:inline-block;padding:13px 30px;background:#0E7490;color:#fff;text-decoration:none;border-radius:10px;font-weight:700;font-size:15px">Refer another host</a>
</div>
</td></tr>
<tr><td style="padding:16px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">Ezynomad.com — long-stay homes for travellers. Questions about this payment? Write to support@ezynomad.com.</td></tr>
</table></td></tr></table></body></html>`;
}

function payoutText(referrerName, refereeName, amount, reference) {
  return `Hi ${referrerName},

Good news. Your referral reward of ${amount} for bringing ${refereeName} to Ezynomad has been paid out.

Amount paid: ${amount}
For referring: ${refereeName}
${reference ? `Payment reference: ${reference}` : ''}

Know another great property owner? Keep referring and keep earning: ${SITE_URL}/refer

Questions about this payment? Write to support@ezynomad.com.

Ezynomad.com`;
}
