-- ═══════════════════════════════════════════════════════════
-- MIGRATION 21 — PER-ROOM MAX GUESTS
-- Partners can set a guest limit for each room type when listing.
-- ═══════════════════════════════════════════════════════════

alter table public.rooms
  add column if not exists max_guests integer default 2;
