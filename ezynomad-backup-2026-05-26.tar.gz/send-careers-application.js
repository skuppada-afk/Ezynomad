// Netlify function: handles job applications from /careers.
// Receives form data + base64-encoded resume, emails it to join@ezynomad.com
// with the resume attached.

const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.FROM_EMAIL || 'support@ezynomad.com';
const FROM_NAME  = 'Ezynomad';
const CAREERS_INBOX = 'join@ezynomad.com';
const SITE_URL = (process.env.SITE_URL || 'https://ezynomad.com').replace(/\/$/, '');

// Max resume size = 5 MB. Anything bigger and Resend's 40 MB attachment limit
// is not the bottleneck; we don't want the function to choke on huge files.
const MAX_RESUME_BYTES = 5 * 1024 * 1024;

// Only allow common resume formats. Filters out spam and dangerous types.
const ALLOWED_RESUME_TYPES = new Set([
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}
function row(label, value) {
  const v = value && String(value).trim() ? esc(value) : '<span style="color:#94A3B8">—</span>';
  return `
    <tr>
      <td style="padding:8px 12px;background:#F8FAFC;border-bottom:1px solid #E2E8F0;font-weight:600;color:#475569;width:170px;font-size:13px;vertical-align:top">${esc(label)}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:13px;vertical-align:top">${v}</td>
    </tr>`;
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const {
      // Anti-bot honeypot. Any value here means a bot filled it in.
      website,
      // Real fields
      name,
      email,
      phone,
      country,
      position,
      linkedin,
      why,
      // Resume: { filename, contentType, base64 }
      resume,
    } = body;

    // Honeypot trap
    if (website && String(website).trim().length > 0) {
      // Pretend success so bots don't iterate
      return {
        statusCode: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        body: JSON.stringify({ ok: true }),
      };
    }

    if (!name || !email || !position) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Name, email and position are required' }) };
    }
    if (!email.includes('@')) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'A valid email is required' }) };
    }

    // Build the email body
    const submittedAt = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'medium',
      timeStyle: 'short',
    });

    const subject = `New application: ${position} — ${name}`;

    const html = `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:620px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">

<tr><td style="padding:22px 28px;background:#0C1A2E;color:#FFFFFF">
  <div style="font-size:12px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">New job application</div>
  <div style="font-size:20px;font-weight:700">${esc(position)}</div>
</td></tr>

<tr><td style="padding:24px 28px">
  <div style="font-size:13px;color:#94A3B8;margin-bottom:14px">Submitted ${esc(submittedAt)} IST</div>

  <div style="font-size:13px;color:#94A3B8;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Candidate</div>
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #E2E8F0;border-radius:8px;overflow:hidden;margin-bottom:22px">
    ${row('Name',     name)}
    ${row('Email',    email)}
    ${row('Phone',    phone)}
    ${row('Location', country)}
    ${row('LinkedIn', linkedin)}
  </table>

  ${why ? `
    <div style="font-size:13px;color:#94A3B8;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Why Ezynomad</div>
    <div style="background:#F0F9FF;border-left:3px solid #0E7490;padding:12px 14px;border-radius:4px;font-size:13px;color:#0C4A6E;margin-bottom:22px;white-space:pre-wrap">${esc(why)}</div>
  ` : ''}

  <div style="background:#FEF3C7;border:1px solid #FCD34D;border-radius:8px;padding:12px 14px;font-size:12px;color:#78350F;margin-bottom:8px">
    <b>Resume attached.</b> Reply directly to this email to reach the candidate.
  </div>
</td></tr>

<tr><td style="padding:14px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">
  Sent from the /careers form on Ezynomad.com.
</td></tr>

</table></td></tr></table></body></html>`;

    const text = `NEW JOB APPLICATION — ${position}
Submitted ${submittedAt} IST

CANDIDATE
  Name:     ${name || '—'}
  Email:    ${email || '—'}
  Phone:    ${phone || '—'}
  Location: ${country || '—'}
  LinkedIn: ${linkedin || '—'}
${why ? `\nWHY EZYNOMAD:\n${why}\n` : ''}
Resume attached.`;

    // Prepare optional resume attachment
    const attachments = [];
    if (resume && resume.base64) {
      // Validate size before sending. The base64 length is ~1.37x of byte length.
      const approxBytes = Math.floor((resume.base64.length * 3) / 4);
      if (approxBytes > MAX_RESUME_BYTES) {
        return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Resume is too large. Maximum 5 MB.' }) };
      }
      if (resume.contentType && !ALLOWED_RESUME_TYPES.has(resume.contentType)) {
        return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Resume must be PDF, DOC, or DOCX.' }) };
      }
      attachments.push({
        filename: (resume.filename || 'resume').replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80),
        content: resume.base64,            // Resend accepts base64 strings directly
      });
    }

    const sendArgs = {
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: CAREERS_INBOX,
      reply_to: email,
      subject,
      html,
      text,
    };
    if (attachments.length) sendArgs.attachments = attachments;

    const r = await resend.emails.send(sendArgs);

    if (r.error) {
      console.log('[careers] Resend error:', r.error.message);
      return { statusCode: 502, headers: corsHeaders, body: JSON.stringify({ error: r.error.message }) };
    }
    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true }),
    };
  } catch (err) {
    console.error('send-careers-application error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};
