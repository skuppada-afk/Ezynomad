// Netlify function: generates a dynamic sitemap.xml from the database.
// Includes the homepage, key static pages, and every active property.
// Search engines (Google, Bing) read this to know what to crawl.

const { createClient } = require('@supabase/supabase-js');

const SITE_URL = (process.env.SITE_URL || 'https://ezynomad.com').replace(/\/$/, '');
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

function xmlEscape(s) {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

exports.handler = async () => {
  try {
    // Static pages that should always be in the sitemap
    const staticPages = [
      { path: '/', priority: '1.0', changefreq: 'daily' },
      { path: '/partner', priority: '0.9', changefreq: 'weekly' },
      { path: '/refer', priority: '0.7', changefreq: 'monthly' },
      { path: '/about', priority: '0.5', changefreq: 'monthly' },
      { path: '/login', priority: '0.3', changefreq: 'yearly' },
      { path: '/signup', priority: '0.5', changefreq: 'yearly' },
    ];

    // Every active, listed property (one URL per property detail page).
    // Note: properties table has created_at but no updated_at column.
    const { data: properties, error: propsErr } = await supabase
      .from('properties')
      .select('id, name, created_at')
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(5000);

    if (propsErr) {
      console.error('[sitemap] supabase query error:', propsErr.message, propsErr);
    }
    console.log('[sitemap] properties fetched:', properties ? properties.length : 'null/undefined');

    const now = new Date().toISOString().slice(0, 10);

    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
    xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

    for (const p of staticPages) {
      xml += '  <url>\n';
      xml += `    <loc>${SITE_URL}${p.path}</loc>\n`;
      xml += `    <lastmod>${now}</lastmod>\n`;
      xml += `    <changefreq>${p.changefreq}</changefreq>\n`;
      xml += `    <priority>${p.priority}</priority>\n`;
      xml += '  </url>\n';
    }

    if (properties && properties.length) {
      for (const prop of properties) {
        const lastmod = (prop.updated_at || prop.created_at || '').slice(0, 10) || now;
        xml += '  <url>\n';
        xml += `    <loc>${SITE_URL}/property/${xmlEscape(prop.id)}</loc>\n`;
        xml += `    <lastmod>${lastmod}</lastmod>\n`;
        xml += `    <changefreq>weekly</changefreq>\n`;
        xml += `    <priority>0.8</priority>\n`;
        xml += '  </url>\n';
      }
    }

    xml += '</urlset>\n';

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/xml; charset=utf-8',
        // No caching while we're iterating. Once stable, can be set to
        // 'public, max-age=3600' to cache for 1 hour.
        'Cache-Control': 'no-cache, no-store, must-revalidate',
      },
      body: xml,
    };
  } catch (err) {
    console.error('sitemap generation error', err);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'text/plain' },
      body: 'Could not generate sitemap',
    };
  }
};
