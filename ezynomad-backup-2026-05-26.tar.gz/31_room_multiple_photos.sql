-- ═══════════════════════════════════════════════════════════
-- MIGRATION 31 — MULTIPLE ROOM PHOTOS
-- Each room type can now have up to 4 photos. Stored as a JSONB
-- array of public URLs. The first entry is the cover photo
-- (kept in photo_url for backward compatibility with existing code
-- that reads a single photo).
-- ═══════════════════════════════════════════════════════════

alter table public.rooms
  add column if not exists photo_urls jsonb default '[]'::jsonb;

-- Backfill: copy any existing single photo_url into photo_urls
update public.rooms
   set photo_urls = jsonb_build_array(photo_url)
 where photo_url is not null
   and (photo_urls is null or jsonb_array_length(photo_urls) = 0);

notify pgrst, 'reload schema';
