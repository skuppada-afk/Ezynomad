// Netlify function: notifies the Ezynomad team at SUPPORT_EMAIL
// whenever someone submits a new referral on /refer.
// Non-blocking: if this fails, the referral is still saved
// (the frontend calls this with .catch).

const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL    = process.env.FROM_EMAIL    || 'support@ezynomad.com';
const FROM_NAME     = 'Ezynomad';
const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL || 'support@ezynomad.com';
const SITE_URL      = (process.env.SITE_URL || 'https://ezynomad.com').replace(/\/$/, '');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function esc(s) {
  return String(s || '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );
}

// Builds a 2-column key/value row for the email table. Empty values
// show as a dash so the email layout stays consistent.
function row(label, value) {
  const v = value && String(value).trim() ? esc(value) : '<span style="color:#94A3B8">—</span>';
  return `
    <tr>
      <td style="padding:8px 12px;background:#F8FAFC;border-bottom:1px solid #E2E8F0;font-weight:600;color:#475569;width:160px;font-size:13px;vertical-align:top">${esc(label)}</td>
      <td style="padding:8px 12px;border-bottom:1px solid #E2E8F0;color:#0F172A;font-size:13px;vertical-align:top">${v}</td>
    </tr>`;
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: corsHeaders, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: corsHeaders, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const {
      // referrer
      referrer_name,
      referrer_email,
      referrer_phone,
      referrer_country,
      is_logged_in,
      // referred property
      referee_property_name,
      referee_name,
      referee_email,
      referee_phone,
      referee_whatsapp,
      referee_country,
      // optional note
      note,
    } = JSON.parse(event.body || '{}');

    if (!referrer_email && !referee_email) {
      return { statusCode: 400, headers: corsHeaders, body: JSON.stringify({ error: 'Missing referral data' }) };
    }

    const submittedAt = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      dateStyle: 'medium',
      timeStyle: 'short',
    });
    const referrerType = is_logged_in
      ? '<span style="color:#16A34A;font-weight:600">Logged-in user</span>'
      : '<span style="color:#0E7490;font-weight:600">Guest (not yet registered)</span>';

    const subjectProperty = referee_property_name || referee_name || 'a property';
    const subjectLocation = referee_country ? ` in ${referee_country}` : '';
    const subject = `New referral: ${subjectProperty}${subjectLocation}`;

    const html = `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F8FAFC;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;color:#0F172A;line-height:1.5">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F8FAFC;padding:24px 12px"><tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="max-width:620px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)">

<tr><td style="padding:22px 28px;background:#0C1A2E;color:#FFFFFF">
  <div style="font-size:12px;opacity:.7;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:4px">Internal · Admin notification</div>
  <div style="font-size:20px;font-weight:700">New referral submitted</div>
</td></tr>

<tr><td style="padding:24px 28px">
  <div style="font-size:14px;color:#475569;margin-bottom:18px">
    Submitted ${esc(submittedAt)} IST · Referrer is ${referrerType}.
  </div>

  <div style="font-size:13px;color:#94A3B8;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px;margin-top:6px">Referrer</div>
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #E2E8F0;border-radius:8px;overflow:hidden;margin-bottom:22px">
    ${row('Name',    referrer_name)}
    ${row('Email',   referrer_email)}
    ${row('Phone',   referrer_phone)}
    ${row('Country', referrer_country)}
  </table>

  <div style="font-size:13px;color:#94A3B8;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Property referred</div>
  <table width="100%" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #E2E8F0;border-radius:8px;overflow:hidden;margin-bottom:22px">
    ${row('Property',  referee_property_name)}
    ${row('Contact',   referee_name)}
    ${row('Email',     referee_email)}
    ${row('Phone',     referee_phone)}
    ${row('WhatsApp',  referee_whatsapp)}
    ${row('Country',   referee_country)}
  </table>

  ${note ? `
    <div style="font-size:13px;color:#94A3B8;text-transform:uppercase;letter-spacing:1px;font-weight:600;margin-bottom:8px">Note from referrer</div>
    <div style="background:#FEF3C7;border-left:3px solid #F59E0B;padding:12px 14px;border-radius:4px;font-size:13px;color:#78350F;margin-bottom:22px;white-space:pre-wrap">${esc(note)}</div>
  ` : ''}

  <div style="background:#F0F9FF;border:1px solid #BAE6FD;border-radius:8px;padding:12px 14px;font-size:12px;color:#075985;margin-bottom:8px">
    <b>Bounty if qualified:</b> $5 USD to the referrer when this property goes active.
  </div>

  <div style="text-align:center;margin:24px 0 4px">
    <a href="${SITE_URL}/admin" style="display:inline-block;padding:11px 24px;background:#0E7490;color:#fff;text-decoration:none;border-radius:8px;font-weight:700;font-size:14px">Open Referrals console</a>
  </div>
</td></tr>

<tr><td style="padding:14px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:11px;color:#94A3B8">
  This is an internal notification sent to ${esc(SUPPORT_EMAIL)} when a new referral is submitted on Ezynomad.com.
</td></tr>

</table></td></tr></table></body></html>`;

    const text = `NEW REFERRAL SUBMITTED
Submitted ${submittedAt} IST · Referrer is ${is_logged_in ? 'logged-in' : 'guest'}.

REFERRER
  Name:    ${referrer_name || '—'}
  Email:   ${referrer_email || '—'}
  Phone:   ${referrer_phone || '—'}
  Country: ${referrer_country || '—'}

PROPERTY REFERRED
  Property:  ${referee_property_name || '—'}
  Contact:   ${referee_name || '—'}
  Email:     ${referee_email || '—'}
  Phone:     ${referee_phone || '—'}
  WhatsApp:  ${referee_whatsapp || '—'}
  Country:   ${referee_country || '—'}
${note ? `\nNOTE FROM REFERRER:\n${note}\n` : ''}
Bounty if qualified: $5 USD to the referrer when this property goes active.

Open the Referrals console: ${SITE_URL}/admin`;

    const r = await resend.emails.send({
      from: `${FROM_NAME} <${FROM_EMAIL}>`,
      to: SUPPORT_EMAIL,
      reply_to: referrer_email || undefined,
      subject,
      html,
      text,
    });

    if (r.error) {
      console.log('[admin-referral] Resend error:', r.error.message);
      return { statusCode: 502, headers: corsHeaders, body: JSON.stringify({ error: r.error.message }) };
    }
    return {
      statusCode: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, id: r.data?.id || null }),
    };
  } catch (err) {
    console.error('send-admin-referral-notification error', err);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: String(err.message || err) }),
    };
  }
};
